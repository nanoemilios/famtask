-- Adminer 4.8.1 MySQL 10.11.14-MariaDB-0+deb12u2 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admin_settings`;
CREATE TABLE `admin_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_settings` (`id`, `password_hash`, `created_at`) VALUES
(1,	'$2y$10$9rBvWUHyZ5bV2Ey84HL2b.X7w2S5eU5q3YOwA9AmzH435oc14UFwK',	'2026-03-14 17:07:26');

DROP TABLE IF EXISTS `children`;
CREATE TABLE `children` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `avatar` varchar(255) DEFAULT '',
  `color` varchar(20) DEFAULT '#6366F1',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `children` (`id`, `name`, `avatar`, `color`, `created_at`) VALUES
(1,	'Samuel',	'',	'#0004ff',	'2026-03-14 17:07:26'),
(2,	'Santiago',	'',	'#ff0000',	'2026-03-14 17:07:26');

DROP TABLE IF EXISTS `scheduled_tasks`;
CREATE TABLE `scheduled_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `scheduled_date` date NOT NULL,
  `scheduled_time` time NOT NULL,
  `repeat_type` enum('none','daily','weekly','monthly') DEFAULT 'none',
  `repeat_until` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  CONSTRAINT `scheduled_tasks_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `scheduled_tasks` (`id`, `task_id`, `scheduled_date`, `scheduled_time`, `repeat_type`, `repeat_until`, `created_at`) VALUES
(1,	6,	'2026-03-14',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(2,	6,	'2026-03-15',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(3,	6,	'2026-03-16',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(4,	6,	'2026-03-17',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(5,	6,	'2026-03-18',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(6,	6,	'2026-03-19',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(7,	6,	'2026-03-20',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(8,	6,	'2026-03-21',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(9,	6,	'2026-03-22',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(10,	6,	'2026-03-23',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(11,	6,	'2026-03-24',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(12,	6,	'2026-03-25',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(13,	6,	'2026-03-26',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(14,	6,	'2026-03-27',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(15,	6,	'2026-03-28',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(16,	6,	'2026-03-29',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(17,	6,	'2026-03-30',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30'),
(18,	6,	'2026-03-31',	'08:30:00',	'daily',	'2026-03-31',	'2026-03-14 17:11:30');

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `minutes_reward` int(11) DEFAULT 15,
  `category` varchar(50) DEFAULT 'Hausaufgaben',
  `image` varchar(500) DEFAULT '',
  `child_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`child_id`) REFERENCES `children` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tasks` (`id`, `title`, `description`, `minutes_reward`, `category`, `image`, `child_id`, `created_by`, `created_at`) VALUES
(1,	'Hausaufgaben Mathe',	'Mathematik Aufgaben erledigen',	15,	'Hausaufgaben',	'',	2,	1,	'2026-03-14 17:07:26'),
(2,	'Hausaufgaben',	'Hausaufgaben erledigen',	30,	'Hausaufgaben',	'',	2,	1,	'2026-03-14 17:07:26'),
(3,	'Zimmer aufräumen',	'Zimmer sauber machen',	20,	'Haushalt',	'',	NULL,	1,	'2026-03-14 17:07:26'),
(4,	'Müll rausbringen',	'Müllcontainer leeren',	10,	'Haushalt',	'',	NULL,	1,	'2026-03-14 17:07:26'),
(6,	'Bett machen',	'Bett machen',	15,	'Haushalt',	'🛏️',	NULL,	1,	'2026-03-14 17:10:23');

DROP TABLE IF EXISTS `task_completions`;
CREATE TABLE `task_completions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  `completed_at` timestamp NULL DEFAULT current_timestamp(),
  `minutes_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `task_completions_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `task_completions_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `children` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `timers`;
CREATE TABLE `timers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `child_id` int(11) NOT NULL,
  `activity_name` varchar(255) DEFAULT 'Freizeit',
  `started_at` timestamp NULL DEFAULT current_timestamp(),
  `paused_at` timestamp NULL DEFAULT NULL,
  `is_running` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `timers_ibfk_1` FOREIGN KEY (`child_id`) REFERENCES `children` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `timer_logs`;
CREATE TABLE `timer_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `child_id` int(11) NOT NULL,
  `activity_name` varchar(255) DEFAULT NULL,
  `duration_minutes` int(11) NOT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `ended_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `timer_logs_ibfk_1` FOREIGN KEY (`child_id`) REFERENCES `children` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `time_credits`;
CREATE TABLE `time_credits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `child_id` int(11) NOT NULL,
  `minutes_total` int(11) DEFAULT 0,
  `minutes_used` int(11) DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `child_id` (`child_id`),
  CONSTRAINT `time_credits_ibfk_1` FOREIGN KEY (`child_id`) REFERENCES `children` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `time_credits` (`id`, `child_id`, `minutes_total`, `minutes_used`, `updated_at`) VALUES
(1,	1,	60,	0,	'2026-03-14 17:07:26'),
(2,	2,	60,	0,	'2026-03-14 17:07:26');

-- 2026-03-15 14:50:11
